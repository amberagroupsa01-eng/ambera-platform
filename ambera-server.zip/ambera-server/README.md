# 🌿 Ambéra Platform

> La richesse de la nature dans chaque bouchée

## Déploiement sur Render.com (5 minutes)

### Étape 1 — Mettre le code sur GitHub
1. Allez sur **github.com** → New repository
2. Nom : `ambera-platform`
3. Cliquez **Create repository**
4. Glissez-déposez ces 3 fichiers :
   - `server.js`
   - `package.json`
   - le dossier `public/` avec `index.html`

### Étape 2 — Déployer sur Render.com
1. Allez sur **render.com**
2. Cliquez **New** → **Web Service**
3. Connectez votre repo GitHub `ambera-platform`
4. Paramètres :
   - **Build Command** : `npm install`
   - **Start Command** : `npm start`
5. Cliquez **Create Web Service**

### Étape 3 — Votre site est en ligne !
Render vous donne une URL :
`https://ambera-platform.onrender.com`

## Structure du projet
```
ambera-platform/
├── server.js          ← Serveur Node.js
├── package.json       ← Dépendances
└── public/
    └── index.html     ← Page d'accueil Ambéra
```

## Prochaines étapes
- [ ] Système de connexion (login/inscription)
- [ ] Base de données utilisateurs
- [ ] Module Market fonctionnel
- [ ] Paiements Orange Money / MTN MoMo
